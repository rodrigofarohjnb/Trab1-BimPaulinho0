package com.example.notasgerenciamnt;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etNome, etEmail, etIdade, etDisciplina, etNota1, etNota2;
    Button btnEnviar, btnLimpar;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        btnEnviar = findViewById(R.id.btnEnviar);
        btnLimpar = findViewById(R.id.btnLimpar);
        tvResultado = findViewById(R.id.tvResultado);


        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validarCampos()) {
                    calcularMedia();
                }
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparCampos();
            }
        });
    }

    private boolean validarCampos() {
        String nome = etNome.getText().toString();
        String email = etEmail.getText().toString();
        String idade = etIdade.getText().toString();
        String nota1 = etNota1.getText().toString();
        String nota2 = etNota2.getText().toString();

        if (nome.isEmpty()) {
            tvResultado.setText("O campo de nome está vazio");
            tvResultado.setVisibility(View.VISIBLE);
            return false;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tvResultado.setText("O email é inválido");
            tvResultado.setVisibility(View.VISIBLE);
            return false;
        }
        if (idade.isEmpty() || Integer.parseInt(idade) <= 0) {
            tvResultado.setText("A idade deve ser um número positivo");
            tvResultado.setVisibility(View.VISIBLE);
            return false;
        }
        if (nota1.isEmpty() || Float.parseFloat(nota1) < 0 || Float.parseFloat(nota1) > 10) {
            tvResultado.setText("Nota 1 deve ser entre 0 e 10");
            tvResultado.setVisibility(View.VISIBLE);
            return false;
        }
        if (nota2.isEmpty() || Float.parseFloat(nota2) < 0 || Float.parseFloat(nota2) > 10) {
            tvResultado.setText("Nota 2 deve ser entre 0 e 10");
            tvResultado.setVisibility(View.VISIBLE);
            return false;
        }
        tvResultado.setVisibility(View.GONE);
        return true;
    }

    private void calcularMedia() {
        String nome = etNome.getText().toString();
        String email = etEmail.getText().toString();
        String idade = etIdade.getText().toString();
        String disciplina = etDisciplina.getText().toString();
        float nota1 = Float.parseFloat(etNota1.getText().toString());
        float nota2 = Float.parseFloat(etNota2.getText().toString());
        float media = (nota1 + nota2) / 2;

        String status = media >= 6 ? "Aprovado" : "Reprovado";

        String resultado = "Nome: " + nome + "\nEmail: " + email + "\nIdade: " + idade +
                "\nDisciplina: " + disciplina + "\nNotas 1o e 2o Bimestres: " + nota1 + " e " + nota2 +
                "\nMédia: " + media + "\nStatus: " + status;

        tvResultado.setText(resultado);
        tvResultado.setVisibility(View.VISIBLE);
    }

    private void limparCampos() {
        etNome.setText("");
        etEmail.setText("");
        etIdade.setText("");
        etDisciplina.setText("");
        etNota1.setText("");
        etNota2.setText("");
        tvResultado.setVisibility(View.GONE);
    }
}